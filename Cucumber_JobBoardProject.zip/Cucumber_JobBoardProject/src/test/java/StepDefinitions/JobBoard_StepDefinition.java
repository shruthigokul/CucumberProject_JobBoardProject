package StepDefinitions;

import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.an.Y;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.bytebuddy.dynamic.DynamicType.Builder.MethodDefinition.ParameterDefinition.Initial;

public class JobBoard_StepDefinition {
	WebDriver driver=null;	
	WebDriverWait wait=null;
	 String username="raply";
	 String emailid="raply@gmail.com";
	 String jobTitle=null;
	@Before
	public void init()
	{
		System.setProperty("webdriver.gecko.driver","C:\\Users\\ShruthiGokul\\Downloads\\geckodriver-v0.27.0-win64\\geckodriver.exe");
	 	driver=new FirefoxDriver();
	 	
	 	
	}
	
	
	@Given("^User should be able to login with username-\"(.*)\" and password-\"(.*)\"$")
	public void givenFunctionName(String username,String password)
	{
		driver.get("https://alchemy.hguy.co/jobs/wp-admin");
		driver.manage().window().maximize();
	 	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	 	driver.findElement(By.id("user_login")).sendKeys(username);
		driver.findElement(By.id("user_pass")).sendKeys(password);
		driver.findElement(By.id("wp-submit")).click();
		wait=new WebDriverWait(driver,10);
		wait.until(ExpectedConditions.titleContains("Dashboard ‹ Alchemy Jobs — WordPress"));	
	}
	
	
	 @Given("^User clicks on Add new Btn$")
	 public void clickAddNewUser() throws InterruptedException
	 {
		
		 //Locate the “Add New” button and click it.
		 Actions actions=new Actions(driver);
		 actions.moveToElement(driver.findElement(By.partialLinkText("New"))).build().perform();
		 driver.findElement(By.linkText("User")).click();

	 }
	 
	 
	 @When("^User should all details to create User$")
	 public void EnterUserDetails() throws InterruptedException
	 {
		//Verify if add new user page is displayed
		 wait=new WebDriverWait(driver, 5);
		 wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//h1[@id='add-new-user']"))));
		 
		 //enter the details
		 driver.findElement(By.id("user_login")).sendKeys(username);
		 driver.findElement(By.id("email")).sendKeys(emailid);
		//click add new user button
		 driver.findElement(By.id("createusersub")).click();
		 Thread.sleep(5000);
		 
	 }
	
	 @Then("^Validate if the new user is created$")
	 public void ValidateUserCreated()
	 {
		 wait.until(ExpectedConditions.visibilityOf(driver.findElement(By.xpath("//h1[contains(text(),'Users')]"))));
		 driver.findElement(By.id("user-search-input")).sendKeys(username);
		 driver.findElement(By.id("search-submit")).click();
		 
		 System.out.println(driver.findElement(By.xpath("//table[@class='wp-list-table widefat fixed striped users']//td/strong/a")).getText());
		 
		Assert.assertEquals(username,driver.findElement(By.xpath("//table[@class='wp-list-table widefat fixed striped users']//td/strong/a")).getText());
		
	 }
	 
	  @Given("^User should be able to navigate to alchemy job site$")
	  public void navigateToAlchemyJobsite()
	  {
		  	driver.get("https://alchemy.hguy.co/jobs/");
			driver.manage().window().maximize();
		 	
	  }
	  @And("^Navigate to job search page$")
	  public void navigateToJobSearchPage() throws InterruptedException
	  {
		  driver.findElement(By.xpath("//li[@id='menu-item-24']/a")).click();
		 	wait=new WebDriverWait(driver,10);
			wait.until(ExpectedConditions.titleContains("Jobs – Alchemy Jobs"));
		
	  }
	  @When("^Full time jobs are being searched by user$")
	  public void SearchForFullTimeJobs() throws InterruptedException
	  {
		  driver.findElement(By.xpath("//input[@id='search_keywords']")).sendKeys("UFT Tester");
		  List<WebElement> allCheckBox=driver.findElements(By.xpath("//input[@type='checkbox' and @id!='job_type_full-time']"));
		  
		  for(int i=0;i<allCheckBox.size();i++)
		  {
			  allCheckBox.get(i).click();
		  }
		 Thread.sleep(5000);
		  
		  
		  
	  }
	  
	  @Then("^Full time search jobs that are fetched should be validated$")
	  public void ValidateFullTimeJobsFetched() throws InterruptedException
	  {
		  driver.findElement(By.xpath("//a[contains(@href,'uft')]")).click();
		  Thread.sleep(5000);
		  System.out.println(driver.getTitle());
		 
		  
	  }
	  @And("^Apply for Job button should be clicked$")
	  public void ClickApplyForJobButton()
	  {
		  driver.findElement(By.xpath("//input[@class='application_button button']")).click(); 
	  }
	
	  @And("^Navigate to Post Job page$")
	  public void PostJobPage() {
		driver.findElement(By.xpath("//a[contains(@href,'post-a-job')]")).click();

	}
	  
	  @When("^Job Post details are entered$")
	  public void EnterJobPostDetails(DataTable table) throws InterruptedException {
		  List<Map<String,String>> data = table.asMaps(String.class,String.class);
		  
		  driver.findElement(By.id("create_account_email")).sendKeys(data.get(0).get("Email"));
		  jobTitle=data.get(0).get("Title");
		  driver.findElement(By.id("job_title")).sendKeys(data.get(0).get("Title"));
		  
		  Select drpJobType=new Select(driver.findElement(By.id("job_type")));
		  drpJobType.selectByVisibleText(data.get(0).get("JobType"));
		  
		  driver.switchTo().frame("job_description_ifr");
		  driver.findElement(By.id("tinymce")).sendKeys("just filll");
		  driver.switchTo().defaultContent();
		  driver.findElement(By.id("application")).sendKeys(data.get(0).get("AppUrl"));
		  
		  driver.findElement(By.id("company_name")).sendKeys(data.get(0).get("Company"));
		  
		

	}
	  @And("^Submitted to the portal$")
	  public void SubmitJob() throws InterruptedException {
		  JavascriptExecutor js = (JavascriptExecutor) driver;
		  js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
		  driver.findElement(By.xpath("//input[@name='submit_job']")).click();
		  Thread.sleep(3000);
		  driver.findElement(By.id("job_preview_submit_button")).click();
		  Thread.sleep(3000);

		}
	  

	  @Then("^Posted Job should be present$")
	  public void VerifyJobEntered() throws InterruptedException {
			driver.findElement(By.partialLinkText("click here")).click();
			Thread.sleep(2000);
			String actualJobTitle=driver.findElement(By.xpath("//div[@class='ast-single-post-order']/h1[@class='entry-title']")).getText();
			Assert.assertEquals(actualJobTitle,jobTitle);
		}
	  
		@When("^Enter \"(.*)\", \"(.*)\",\"(.*)\",\"(.*)\",\"(.*)\"$")
		public void enterJobDetails(String email,String title,String jobType,String appUrl,String Company) throws InterruptedException {
			
			 driver.findElement(By.id("create_account_email")).sendKeys(email);
			  jobTitle=title;
			  driver.findElement(By.id("job_title")).sendKeys(title);
			  
			  Select drpJobType=new Select(driver.findElement(By.id("job_type")));
			  drpJobType.selectByVisibleText(jobType);
			  
			  driver.switchTo().frame("job_description_ifr");
			  driver.findElement(By.id("tinymce")).sendKeys("just filll");
			  driver.switchTo().defaultContent();
			  driver.findElement(By.id("application")).sendKeys(appUrl);
			  Thread.sleep(3000);
			  
			  driver.findElement(By.id("company_name")).sendKeys(Company);
			 
		}
	 @After()
	 public void endTest()
	 {
		 driver.quit();
	 }
	
	
	
	
	

}
