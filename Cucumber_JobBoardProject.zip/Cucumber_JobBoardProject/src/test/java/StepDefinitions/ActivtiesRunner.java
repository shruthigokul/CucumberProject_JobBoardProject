package StepDefinitions;



	
	/*
import org.junit.runner.RunWith;
import cucumber.api.*;
import io.cucumber.junit.CucumberOptions;*/

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
 
@RunWith(Cucumber.class)
@CucumberOptions(
    features = "src/test/java/Features",
    glue = "StepDefinitions",
    tags = "@PostAJobWithScenOutline",
    plugin = {"html: test-reports"}
    //strict = true
)
 
public class ActivtiesRunner {
    //empty
}

