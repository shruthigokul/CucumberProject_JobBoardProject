package StepDefinitions;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.cucumber.java.After;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;


public class Activity1_1_StepDefinition {
WebDriver driver=null; 
	
	@Given("^User is on Google Home Page$")
	public void givenFunctionName() {
		
	System.setProperty("webdriver.gecko.driver","C:\\Users\\ShruthiGokul\\Downloads\\geckodriver-v0.27.0-win64\\geckodriver.exe");
 	driver=new FirefoxDriver();
 	driver.get("https://www.Google.com");
 	driver.manage().window().maximize();
 	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
 	
	}

	@When("^User types in Cheese and hits ENTER$")
	public void whenFunctionName() {
		
		driver.findElement(By.name("q")).sendKeys("Cheese");
		driver.findElement(By.name("q")).sendKeys(Keys.ENTER);
	}

	@Then("^Show how many search results were shown$")
	public void thenFunctionName() {
		
		String resultStats = driver.findElement(By.id("result-stats")).getText();
        System.out.println("Number of results found: " + resultStats);
	}
	
	 @And("^Close the browser$")
	    public void closeTheBrowser() throws Throwable {
	        driver.close();
	    }
	
	 

	 




}
